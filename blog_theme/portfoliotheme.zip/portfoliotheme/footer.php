<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package deepakPortfolioTheme
 */

?>



	<div class="container-fluid py-1 px-0 border-top"> 


  <div class="container">

    <footer class=" py-3 my-4">

<div class="row">

  <div class="col-12 text-center">
      <p class="mb-0 text-muted">&copy; 2021 <a href="https://www.kdeepakraj.com/" class="mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
      <span class="ms-5 d-inline-block"> Deepak Madhana Raj</span></a></p>
      </div>
      
    </div>

    </footer>

  </div>

</div>


  <!--------------- javascript  ------------------->
  
<button type="button" onclick="topFunction()" id="myBtn" title="Go to top"><i class="bi bi-arrow-up-short" style="font-size: 1.6rem; margin:0; padding:0; position: absolute; right:0: top:0 "></i></button>




<?php wp_footer(); ?>

</body>
</html>
