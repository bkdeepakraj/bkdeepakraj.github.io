<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package deepakPortfolioTheme
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

  <!-- Favicons 
  <link href="/assets/images/favicon.png" rel="icon">
    <link href="/assets/images/apple-touch-icon.png" rel="apple-touch-icon">  -->

    <!-- Google font CSS -->
  
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,200;0,300;0,400;0,500;0,600;1,300&display=swap" rel="stylesheet">

    <!-- Bootstrap Icons -->

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">



	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?> onload="myPlaceholder()">
<?php wp_body_open(); ?>

<button type="button" onclick="topFunction()" id="myBtn" title="Go to top"><i class="bi bi-arrow-up-short" style="font-size: 1.6rem;"></i></button>


<div class="container-fluid topheaderfill">

</div>

	<nav class="navbar navbar-light navbar-expand-lg navbar-expand-xl navbar-expand-xxl bg-light sticky-top site-header">
        <div class="container">
          <a class="navbar-brand contdisplaynone font-weight600 font-40" href="#">kdeepakraj</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
            <div class="offcanvas-header">
              <h5 class="offcanvas-title font-weight600" id="offcanvasNavbarLabel"></h5>
              <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">

			<?php 

			wp_nav_menu( array(
    'theme_location'  => 'primary',
    'depth'           => 2, // 1 = no dropdowns, 2 = with dropdowns.
    'container'       => 'ul',
    
    'container_id'    => 'bs-example-navbar-collapse-1', 
    'menu_class'      => 'navbar-nav flex-sm-shrink-1 flex-md-shrink-1 flex-lg-fill font-30 text-center',
    'container'       => 'li',
	'container_class' => '',

    'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
    'walker'          => new WP_Bootstrap_Navwalker(),
) );


?>
    
              
            </div>
          </div>
        </div>
      </nav>
	


